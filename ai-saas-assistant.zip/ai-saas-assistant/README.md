# 🚀 AI SaaS Assistant

Production-ready AI backend with modular architecture.

## Features
- REST API (Flask)
- Task generation & summarization
- Modular services
- Clean architecture
- Ready for OpenAI/Claude integration

## Run
```bash
pip install -r requirements.txt
python run.py
```

## Structure
- app/routes → API routes
- app/services → business logic
- app/models → data models
- tests → unit tests
