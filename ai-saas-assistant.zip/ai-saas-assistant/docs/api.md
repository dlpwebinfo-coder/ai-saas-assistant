# API Docs

POST /tasks
POST /summarize
