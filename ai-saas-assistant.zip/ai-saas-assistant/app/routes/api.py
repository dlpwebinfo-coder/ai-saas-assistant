from flask import Blueprint, request, jsonify
from app.services.ai_service import generate_tasks, summarize_text

api_bp = Blueprint("api", __name__)

@api_bp.route("/")
def home():
    return {"status": "running"}

@api_bp.route("/tasks", methods=["POST"])
def tasks():
    data = request.json
    return jsonify(generate_tasks(data.get("text", "")))

@api_bp.route("/summarize", methods=["POST"])
def summarize():
    data = request.json
    return jsonify({"summary": summarize_text(data.get("text", ""))})
