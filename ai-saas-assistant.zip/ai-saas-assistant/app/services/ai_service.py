def generate_tasks(text):
    sentences = text.split(".")
    return {"tasks": [s.strip() for s in sentences if s.strip()]}

def summarize_text(text):
    sentences = text.split(".")
    return ".".join(sentences[:2]).strip()
